﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Domain.Models
{
    public class Resume
    {
        public Guid Id { get; set; }

        public string? Title { get; set; }

        public byte[]? File { get; set; }
        [JsonIgnore]
        public virtual ICollection<JobSeekerProfile> JobSeekerProfiles { get; set; } = new List<JobSeekerProfile>();
    }
}

